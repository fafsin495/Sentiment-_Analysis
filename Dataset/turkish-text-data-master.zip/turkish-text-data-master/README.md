# Turkish Product Reviews
This repository contains 235.165 product reviews collected online. There are 220.284 positive, 14881 negative reviews.
